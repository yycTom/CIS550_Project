// Private. Will not be included in submission
module.exports = {
  host: "cis550-proj.clnp5uhs5ubc.us-east-1.rds.amazonaws.com",
  port: "3306",
  user: "admin",
  password: "cis550-proj",
  database: "cis550",
  multipleStatements: true
};

